#include "kernel/param.h"
#include "kernel/types.h"
#include "kernel/pstat.h"
#include "user/user.h"

struct uproc uproc[NPROC];
int nprocs;

void pstreePrint(int process, int indent){
	for(int i = 0; i < indent; i++){
		printf("  ");
	}
	printf("%s(%d)\n",uproc[process].name, uproc[process].pid);
}

// helper function to output the process tree rooted at pid
// calls itself recursively on any children of pid
void mktree(int indent, int pid)
{
	int i;
	for(i = 0; i < nprocs; i++){
		if(uproc[i].pid == pid){
			break;
		}
	}

	pstreePrint(i, indent);

	int j;
	for(j = 0; j < nprocs; j++){
                if(uproc[j].ppid == uproc[i].pid){
                        mktree(indent + 1, uproc[j].pid);
                }
        }
}

int
main(int argc, char **argv)
{
  int pid = 1;
  if (argc == 2)
    pid = atoi(argv[1]);
  nprocs = getprocs(uproc);
  if (nprocs < 0)
    exit(-1);

  // You can remove the following print statement
  printf("%d processes\n", nprocs);

  mktree(0, pid);
  exit(0);
}
