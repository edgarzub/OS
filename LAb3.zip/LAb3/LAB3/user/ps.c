#include "kernel/param.h"
#include "kernel/types.h"
#include "kernel/pstat.h"
#include "user/user.h"

int
main(int argc, char **argv){
  struct uproc uproc[NPROC];
  int nprocs;

  static char *states[] = {
  [UNUSED]    "unused",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  
  static char *state;

  nprocs = getprocs(uproc);
  if (nprocs < 0)
    exit(-1);

   printf("pid\tstate\tsize\tppid\tname\tcputime\tpriority\n");
   for(int i = 0; i < nprocs; i++){
	state = states[uproc[i].state];
	printf("%d\t%s\t%d\t%d\t%s\t%d\t%d\n", uproc[i].pid, state, uproc[i].size, uproc[i].ppid, uproc[i].name, uproc[i].cputime, uproc[i].priority); 

   }
  exit(0);
}
