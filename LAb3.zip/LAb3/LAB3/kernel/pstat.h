struct uproc{
        int pid;
        enum procstate state;
        uint64 size;
        int ppid;
        char name[16];
        uint cputime;
	uint arrtime;
	int priority;
};
struct rusage{
        uint cputime;
};
